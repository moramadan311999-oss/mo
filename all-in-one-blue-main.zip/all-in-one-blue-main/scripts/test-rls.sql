-- =============================================================
-- RLS test suite for the ERP schema.
-- Runs as the `authenticated` role and forges auth.uid() via
-- request.jwt.claims so RLS policies see different identities.
--
-- Each assertion uses ASSERT inside a DO block; the script aborts
-- on the first failure with a clear message. A final summary row
-- is printed on success.
--
-- Usage:
--   psql -v ON_ERROR_STOP=1 -f scripts/test-rls.sql
-- =============================================================

BEGIN;

-- Speed: keep everything in this txn; rollback at the end.
SET LOCAL client_min_messages = WARNING;
-- Bypass FK to auth.users so we can seed synthetic identities. RLS is
-- NOT affected by session_replication_role; only triggers/FKs are.
SET LOCAL session_replication_role = replica;

-- Fixed UUIDs for synthetic test users.
\set admin_id      '11111111-1111-1111-1111-111111111111'
\set manager_id    '22222222-2222-2222-2222-222222222222'
\set accountant_id '33333333-3333-3333-3333-333333333333'
\set hr_id         '44444444-4444-4444-4444-444444444444'
\set employee_id   '55555555-5555-5555-5555-555555555555'

-- Seed role rows as superuser (current session role) before switching
-- to `authenticated`. ON CONFLICT keeps the suite idempotent.
INSERT INTO public.user_roles (user_id, role) VALUES
  (:'admin_id',      'admin'),
  (:'manager_id',    'manager'),
  (:'accountant_id', 'accountant'),
  (:'hr_id',         'hr'),
  (:'employee_id',   'employee')
ON CONFLICT (user_id, role) DO NOTHING;

-- Helper: switch identity for the rest of the transaction.
CREATE OR REPLACE FUNCTION pg_temp.become(uid uuid) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  PERFORM set_config('role', 'authenticated', true);
  PERFORM set_config(
    'request.jwt.claims',
    json_build_object('sub', uid::text, 'role', 'authenticated')::text,
    true
  );
END $$;

-- Helper: assert that a query returns rows / no rows under current identity.
CREATE OR REPLACE FUNCTION pg_temp.can_select(tbl text) RETURNS boolean
LANGUAGE plpgsql AS $$
DECLARE n int;
BEGIN
  EXECUTE format('SELECT count(*) FROM %s', tbl) INTO n;
  RETURN true; -- if not allowed RLS would not raise; it returns 0 rows. We test by attempting writes for negative.
EXCEPTION WHEN insufficient_privilege THEN
  RETURN false;
END $$;

-- Helper: try an INSERT and report whether it was allowed.
CREATE OR REPLACE FUNCTION pg_temp.try_insert(sql text) RETURNS boolean
LANGUAGE plpgsql AS $$
BEGIN
  EXECUTE sql;
  RETURN true;
EXCEPTION
  WHEN insufficient_privilege THEN RETURN false;
  WHEN check_violation        THEN RETURN false;
  -- RLS WITH CHECK violation surfaces as 42501 / new row violates RLS policy.
  WHEN OTHERS THEN
    IF SQLSTATE = '42501' THEN RETURN false; END IF;
    RAISE;
END $$;

CREATE OR REPLACE FUNCTION pg_temp.try_update(sql text) RETURNS int
LANGUAGE plpgsql AS $$
DECLARE rc int;
BEGIN
  EXECUTE sql;
  GET DIAGNOSTICS rc = ROW_COUNT;
  RETURN rc;
EXCEPTION WHEN insufficient_privilege THEN RETURN -1;
  WHEN OTHERS THEN IF SQLSTATE = '42501' THEN RETURN -1; END IF; RAISE;
END $$;

CREATE OR REPLACE FUNCTION pg_temp.try_delete(sql text) RETURNS int
LANGUAGE plpgsql AS $$
DECLARE rc int;
BEGIN
  EXECUTE sql;
  GET DIAGNOSTICS rc = ROW_COUNT;
  RETURN rc;
EXCEPTION WHEN insufficient_privilege THEN RETURN -1;
  WHEN OTHERS THEN IF SQLSTATE = '42501' THEN RETURN -1; END IF; RAISE;
END $$;

-- =============================================================
-- Test matrix
-- For each (table, role) we record allowed verbs as 'srud' bits:
--   s = SELECT visible (count > 0 of seeded row, or 0 if none seeded but no error)
--   r = INSERT allowed
--   u = UPDATE allowed
--   d = DELETE allowed
-- =============================================================

DO $$
DECLARE
  v_id uuid;
  v_n  int;
  v_ok boolean;
BEGIN
  ---------------------------------------------------------------
  -- Seed one row per business table as admin so SELECT/UPDATE/DELETE
  -- tests have something to act on.
  ---------------------------------------------------------------
  PERFORM pg_temp.become('11111111-1111-1111-1111-111111111111');

  INSERT INTO public.customers (name) VALUES ('rls-test-customer');
  INSERT INTO public.products  (name, price) VALUES ('rls-test-product', 1);
  INSERT INTO public.suppliers (name) VALUES ('rls-test-supplier');
  INSERT INTO public.invoices  (invoice_number) VALUES ('RLS-TEST-001');
  INSERT INTO public.purchase_orders (po_number) VALUES ('RLS-PO-001');
  INSERT INTO public.employees (full_name) VALUES ('rls-test-employee');

  ---------------------------------------------------------------
  -- customers: SELECT admin/manager/accountant only; WRITE same set
  ---------------------------------------------------------------
  -- employee should NOT see, NOT insert
  PERFORM pg_temp.become('55555555-5555-5555-5555-555555555555');
  SELECT count(*) INTO v_n FROM public.customers WHERE name = 'rls-test-customer';
  ASSERT v_n = 0, 'employee should NOT see customers';
  v_ok := pg_temp.try_insert($q$INSERT INTO public.customers(name) VALUES ('x-employee')$q$);
  ASSERT NOT v_ok, 'employee should NOT insert customers';

  -- hr should NOT see, NOT insert
  PERFORM pg_temp.become('44444444-4444-4444-4444-444444444444');
  SELECT count(*) INTO v_n FROM public.customers; ASSERT v_n = 0, 'hr should NOT see customers';
  v_ok := pg_temp.try_insert($q$INSERT INTO public.customers(name) VALUES ('x-hr')$q$);
  ASSERT NOT v_ok, 'hr should NOT insert customers';

  -- accountant: SELECT yes, INSERT/UPDATE/DELETE yes
  PERFORM pg_temp.become('33333333-3333-3333-3333-333333333333');
  SELECT count(*) INTO v_n FROM public.customers WHERE name='rls-test-customer';
  ASSERT v_n = 1, 'accountant should see customers';
  v_ok := pg_temp.try_insert($q$INSERT INTO public.customers(name) VALUES ('acc-add')$q$);
  ASSERT v_ok, 'accountant should insert customers';

  -- manager: full
  PERFORM pg_temp.become('22222222-2222-2222-2222-222222222222');
  ASSERT pg_temp.try_update($q$UPDATE public.customers SET notes='m' WHERE name='rls-test-customer'$q$) = 1,
    'manager should update customers';

  -- admin: full
  PERFORM pg_temp.become('11111111-1111-1111-1111-111111111111');
  ASSERT pg_temp.try_delete($q$DELETE FROM public.customers WHERE name='acc-add'$q$) >= 1,
    'admin should delete customers';

  ---------------------------------------------------------------
  -- products: SELECT admin/manager/accountant; WRITE admin/manager
  ---------------------------------------------------------------
  PERFORM pg_temp.become('55555555-5555-5555-5555-555555555555');
  SELECT count(*) INTO v_n FROM public.products WHERE name='rls-test-product';
  ASSERT v_n = 0, 'employee should NOT see products';

  PERFORM pg_temp.become('33333333-3333-3333-3333-333333333333');
  SELECT count(*) INTO v_n FROM public.products WHERE name='rls-test-product';
  ASSERT v_n = 1, 'accountant should see products';
  ASSERT NOT pg_temp.try_insert($q$INSERT INTO public.products(name,price) VALUES ('p-acc',1)$q$),
    'accountant should NOT insert products';

  PERFORM pg_temp.become('22222222-2222-2222-2222-222222222222');
  ASSERT pg_temp.try_insert($q$INSERT INTO public.products(name,price) VALUES ('p-mgr',1)$q$),
    'manager should insert products';

  ---------------------------------------------------------------
  -- suppliers: SELECT admin/manager; WRITE admin/manager
  ---------------------------------------------------------------
  PERFORM pg_temp.become('33333333-3333-3333-3333-333333333333');
  SELECT count(*) INTO v_n FROM public.suppliers WHERE name='rls-test-supplier';
  ASSERT v_n = 0, 'accountant should NOT see suppliers';

  PERFORM pg_temp.become('22222222-2222-2222-2222-222222222222');
  SELECT count(*) INTO v_n FROM public.suppliers WHERE name='rls-test-supplier';
  ASSERT v_n = 1, 'manager should see suppliers';
  ASSERT pg_temp.try_insert($q$INSERT INTO public.suppliers(name) VALUES ('s-mgr')$q$),
    'manager should insert suppliers';

  ---------------------------------------------------------------
  -- invoices / invoice_items: SELECT admin/manager/accountant; WRITE same
  ---------------------------------------------------------------
  PERFORM pg_temp.become('55555555-5555-5555-5555-555555555555');
  SELECT count(*) INTO v_n FROM public.invoices WHERE invoice_number='RLS-TEST-001';
  ASSERT v_n = 0, 'employee should NOT see invoices';

  PERFORM pg_temp.become('33333333-3333-3333-3333-333333333333');
  ASSERT pg_temp.try_insert($q$INSERT INTO public.invoices(invoice_number) VALUES ('ACC-1')$q$),
    'accountant should insert invoices';

  PERFORM pg_temp.become('44444444-4444-4444-4444-444444444444');
  ASSERT NOT pg_temp.try_insert($q$INSERT INTO public.invoices(invoice_number) VALUES ('HR-1')$q$),
    'hr should NOT insert invoices';

  ---------------------------------------------------------------
  -- purchase_orders / items: SELECT admin/manager; WRITE admin/manager
  ---------------------------------------------------------------
  PERFORM pg_temp.become('33333333-3333-3333-3333-333333333333');
  SELECT count(*) INTO v_n FROM public.purchase_orders WHERE po_number='RLS-PO-001';
  ASSERT v_n = 0, 'accountant should NOT see purchase_orders';
  ASSERT NOT pg_temp.try_insert($q$INSERT INTO public.purchase_orders(po_number) VALUES ('ACC-PO')$q$),
    'accountant should NOT insert purchase_orders';

  PERFORM pg_temp.become('22222222-2222-2222-2222-222222222222');
  ASSERT pg_temp.try_insert($q$INSERT INTO public.purchase_orders(po_number) VALUES ('MGR-PO')$q$),
    'manager should insert purchase_orders';

  ---------------------------------------------------------------
  -- employees: SELECT admin/hr/manager (or self); WRITE admin/hr
  ---------------------------------------------------------------
  PERFORM pg_temp.become('33333333-3333-3333-3333-333333333333');
  SELECT count(*) INTO v_n FROM public.employees WHERE full_name='rls-test-employee';
  ASSERT v_n = 0, 'accountant should NOT see employees';
  ASSERT NOT pg_temp.try_insert($q$INSERT INTO public.employees(full_name) VALUES ('e-acc')$q$),
    'accountant should NOT insert employees';

  PERFORM pg_temp.become('44444444-4444-4444-4444-444444444444');
  ASSERT pg_temp.try_insert($q$INSERT INTO public.employees(full_name) VALUES ('e-hr')$q$),
    'hr should insert employees';

  ---------------------------------------------------------------
  -- payroll: SELECT admin/hr/accountant; WRITE admin/hr
  ---------------------------------------------------------------
  -- seed an employee + payroll as admin
  PERFORM pg_temp.become('11111111-1111-1111-1111-111111111111');
  INSERT INTO public.employees (full_name) VALUES ('pay-emp') RETURNING id INTO v_id;
  INSERT INTO public.payroll (employee_id, pay_period, net_salary)
    VALUES (v_id, '2026-01', 100);

  PERFORM pg_temp.become('22222222-2222-2222-2222-222222222222');
  SELECT count(*) INTO v_n FROM public.payroll;
  ASSERT v_n = 0, 'manager should NOT see payroll';

  PERFORM pg_temp.become('55555555-5555-5555-5555-555555555555');
  ASSERT NOT pg_temp.try_insert(
    format($q$INSERT INTO public.payroll(employee_id,pay_period,net_salary) VALUES (%L,'X',999)$q$, v_id)),
    'employee should NOT insert payroll';

  PERFORM pg_temp.become('44444444-4444-4444-4444-444444444444');
  ASSERT pg_temp.try_insert(
    format($q$INSERT INTO public.payroll(employee_id,pay_period,net_salary) VALUES (%L,'2026-02',1)$q$, v_id)),
    'hr should insert payroll';

  PERFORM pg_temp.become('33333333-3333-3333-3333-333333333333');
  SELECT count(*) INTO v_n FROM public.payroll;
  ASSERT v_n >= 1, 'accountant should see payroll';

  ---------------------------------------------------------------
  -- user_roles: admin-only write; self-or-admin read
  ---------------------------------------------------------------
  PERFORM pg_temp.become('55555555-5555-5555-5555-555555555555');
  ASSERT NOT pg_temp.try_insert(
    $q$INSERT INTO public.user_roles(user_id,role) VALUES ('55555555-5555-5555-5555-555555555555','admin')$q$),
    'employee should NOT self-grant admin role';

  PERFORM pg_temp.become('11111111-1111-1111-1111-111111111111');
  -- admin can read all role rows
  SELECT count(*) INTO v_n FROM public.user_roles;
  ASSERT v_n >= 5, 'admin should see all user_roles';

  RAISE NOTICE 'All RLS assertions passed.';
END $$;

ROLLBACK;