import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, FileText, ShoppingCart, Users, Truck, Package,
  UserCog, Wallet, Shield, LogOut, Receipt,
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter,
} from "@/components/ui/sidebar";
import { useAuth, type AppRole } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";

type Item = { title: string; url: string; icon: any; roles?: AppRole[] };

const groups: { label: string; items: Item[] }[] = [
  {
    label: "الرئيسية",
    items: [{ title: "لوحة التحكم", url: "/dashboard", icon: LayoutDashboard }],
  },
  {
    label: "المبيعات",
    items: [
      { title: "الفواتير", url: "/invoices", icon: FileText },
      { title: "العملاء", url: "/customers", icon: Users },
    ],
  },
  {
    label: "المشتريات",
    items: [
      { title: "أوامر الشراء", url: "/purchases", icon: ShoppingCart },
      { title: "الموردون", url: "/suppliers", icon: Truck },
    ],
  },
  {
    label: "المالية",
    items: [
      { title: "سندات القبض والصرف", url: "/transactions", icon: Receipt, roles: ["admin", "manager", "accountant"] },
    ],
  },
  {
    label: "المخزون",
    items: [{ title: "المنتجات", url: "/products", icon: Package }],
  },
  {
    label: "الموارد البشرية",
    items: [
      { title: "الموظفون", url: "/employees", icon: UserCog, roles: ["admin", "hr", "manager"] },
      { title: "الرواتب", url: "/payroll", icon: Wallet, roles: ["admin", "hr", "accountant"] },
    ],
  },
  {
    label: "الإدارة",
    items: [{ title: "المستخدمون والصلاحيات", url: "/users", icon: Shield, roles: ["admin"] }],
  },
];

export function AppSidebar() {
  const path = useRouterState({ select: (r) => r.location.pathname });
  const { user, roles, signOut, hasAnyRole } = useAuth();

  return (
    <Sidebar side="right" collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border p-4">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-lg bg-sidebar-primary flex items-center justify-center text-sidebar-primary-foreground font-bold">
            ERP
          </div>
          <div className="flex-1 group-data-[collapsible=icon]:hidden">
            <div className="font-bold text-sidebar-foreground">نظام الإدارة</div>
            <div className="text-xs text-sidebar-foreground/60">ERP المتكامل</div>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        {groups.map((group) => {
          const visible = group.items.filter((i) => !i.roles || hasAnyRole(i.roles));
          if (visible.length === 0) return null;
          return (
            <SidebarGroup key={group.label}>
              <SidebarGroupLabel>{group.label}</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {visible.map((item) => (
                    <SidebarMenuItem key={item.url}>
                      <SidebarMenuButton asChild isActive={path === item.url} tooltip={item.title}>
                        <Link to={item.url} className="flex items-center gap-3">
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          );
        })}
      </SidebarContent>
      <SidebarFooter className="border-t border-sidebar-border p-3">
        <div className="flex flex-col gap-2 group-data-[collapsible=icon]:hidden">
          <div className="text-xs text-sidebar-foreground/70 truncate">{user?.email}</div>
          <div className="text-xs text-sidebar-foreground/50">
            {roles.length > 0 ? roles.join("، ") : "—"}
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={signOut}
          className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
        >
          <LogOut className="h-4 w-4 ml-2" />
          <span className="group-data-[collapsible=icon]:hidden">تسجيل الخروج</span>
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}