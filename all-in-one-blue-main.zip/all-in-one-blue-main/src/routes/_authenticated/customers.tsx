import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useMemo, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Plus, Users, Trash2, Pencil, Loader2, Download, ArrowUp, ArrowDown, Search, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { fmtDate } from "@/lib/format";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/customers")({ component: Customers });

type FormState = { name: string; shop_name: string; email: string; phone: string; phone2: string; address: string; notes: string };
const empty: FormState = { name: "", shop_name: "", email: "", phone: "", phone2: "", address: "", notes: "" };

const ALL_COLS: { key: string; label: string }[] = [
  { key: "name", label: "الاسم" },
  { key: "shop_name", label: "اسم المحل" },
  { key: "email", label: "البريد" },
  { key: "phone", label: "الهاتف" },
  { key: "phone2", label: "هاتف آخر" },
  { key: "address", label: "العنوان" },
  { key: "notes", label: "ملاحظات" },
  { key: "created_at", label: "تاريخ الإضافة" },
];

type SortKey = "name" | "shop_name" | "created_at";

const fmtErr = (e: any): string => {
  if (!e) return "خطأ غير معروف";
  const code = e.code ? `[${e.code}] ` : "";
  const details = e.details ? ` — ${e.details}` : "";
  const hint = e.hint ? ` (${e.hint})` : "";
  return `${code}${e.message ?? String(e)}${details}${hint}`;
};

function Customers() {
  const qc = useQueryClient();
  const { user, hasAnyRole } = useAuth();
  const canEdit = !!user && hasAnyRole(["admin", "manager", "accountant"]);
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(empty);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("created_at");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [exportOpen, setExportOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exportScope, setExportScope] = useState<"all" | "page">("all");
  const [selectedCols, setSelectedCols] = useState<string[]>(() => {
    if (typeof window === "undefined") return ALL_COLS.map((c) => c.key);
    try {
      const raw = localStorage.getItem("customers.cols");
      if (raw) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr) && arr.length) return arr.filter((k: string) => ALL_COLS.some((c) => c.key === k));
      }
    } catch {}
    return ALL_COLS.map((c) => c.key);
  });

  const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];
  const [pageSize, setPageSize] = useState<number>(() => {
    if (typeof window === "undefined") return 10;
    const v = Number(localStorage.getItem("customers.pageSize"));
    return PAGE_SIZE_OPTIONS.includes(v) ? v : 10;
  });
  const [page, setPage] = useState(1);

  useEffect(() => { try { localStorage.setItem("customers.pageSize", String(pageSize)); } catch {} }, [pageSize]);
  useEffect(() => { try { localStorage.setItem("customers.cols", JSON.stringify(selectedCols)); } catch {} }, [selectedCols]);

  const { data = [], isLoading } = useQuery({
    queryKey: ["customers"],
    queryFn: async () => (await supabase.from("customers").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let rows = !q ? [...data] : data.filter((r: any) =>
      ["name", "shop_name", "email", "phone", "phone2", "address", "notes"]
        .some((k) => String(r[k] ?? "").toLowerCase().includes(q))
    );
    rows.sort((a: any, b: any) => {
      const av = a[sortKey] ?? "";
      const bv = b[sortKey] ?? "";
      if (av < bv) return sortDir === "asc" ? -1 : 1;
      if (av > bv) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
    return rows;
  }, [data, search, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const paged = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, safePage, pageSize]);

  const toggleSort = (k: SortKey) => {
    if (sortKey === k) setSortDir(sortDir === "asc" ? "desc" : "asc");
    else { setSortKey(k); setSortDir("asc"); }
  };

  const SortIcon = ({ k }: { k: SortKey }) =>
    sortKey !== k ? null : sortDir === "asc" ? <ArrowUp className="inline h-3 w-3" /> : <ArrowDown className="inline h-3 w-3" />;

  const openNew = () => { setEditingId(null); setForm(empty); setFormError(null); setOpen(true); };
  const openEdit = (c: any) => {
    setEditingId(c.id);
    setForm({
      name: c.name ?? "", shop_name: c.shop_name ?? "", email: c.email ?? "",
      phone: c.phone ?? "", phone2: c.phone2 ?? "", address: c.address ?? "", notes: c.notes ?? "",
    });
    setFormError(null);
    setOpen(true);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    setFormError(null);
    try {
      const payload = {
        name: form.name,
        shop_name: form.shop_name || null,
        email: form.email || null,
        phone: form.phone || null,
        phone2: form.phone2 || null,
        address: form.address || null,
        notes: form.notes || null,
      };
      const { error } = editingId
        ? await supabase.from("customers").update(payload).eq("id", editingId)
        : await supabase.from("customers").insert(payload);
      if (error) {
        const msg = fmtErr(error);
        setFormError(msg);
        toast.error(editingId ? "فشل تحديث العميل" : "فشل إضافة العميل", { description: msg });
        return;
      }
      toast.success(editingId ? "تم تحديث العميل بنجاح" : "تمت إضافة العميل بنجاح");
      setOpen(false);
      setForm(empty);
      setEditingId(null);
      qc.invalidateQueries({ queryKey: ["customers"] });
    } catch (err: any) {
      const msg = fmtErr(err);
      setFormError(msg);
      toast.error("خطأ غير متوقع أثناء الحفظ", { description: msg });
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteId || deleting) return;
    setDeleting(true);
    try {
      const { error } = await supabase.from("customers").delete().eq("id", deleteId);
      if (error) {
        toast.error("فشل حذف العميل", { description: fmtErr(error) });
        return;
      }
      toast.success("تم حذف العميل بنجاح");
      setDeleteId(null);
      qc.invalidateQueries({ queryKey: ["customers"] });
    } catch (err: any) {
      toast.error("خطأ غير متوقع أثناء الحذف", { description: fmtErr(err) });
    } finally {
      setDeleting(false);
    }
  };

  const runExport = async () => {
    if (exporting) return;
    if (selectedCols.length === 0) {
      toast.error("اختر عمودًا واحدًا على الأقل");
      return;
    }
    setExporting(true);
    try {
      const cols = ALL_COLS.filter((c) => selectedCols.includes(c.key));
      const source = exportScope === "page" ? paged : filtered;
      const esc = (v: any) => {
        const s = v == null ? "" : String(v);
        return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
      };
      const rows = [
        cols.map((c) => c.label).join(","),
        ...source.map((r: any) => cols.map((c) => esc(r[c.key])).join(",")),
      ];
      const blob = new Blob(["\uFEFF" + rows.join("\n")], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `customers-${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success(`تم تصدير ${source.length} عميل`);
      setExportOpen(false);
    } catch (err: any) {
      toast.error("فشل تصدير CSV", { description: fmtErr(err) });
    } finally {
      setExporting(false);
    }
  };

  return (
    <>
      <PageHeader
        title="العملاء"
        description="إدارة قاعدة عملائك"
        action={
          <div className="flex gap-2">
            {canEdit && (
              <Button variant="outline" onClick={() => setExportOpen(true)} disabled={data.length === 0 || exporting}>
                {exporting ? <Loader2 className="h-4 w-4 ml-1 animate-spin" /> : <Download className="h-4 w-4 ml-1" />}
                {exporting ? "جاري التصدير..." : "تصدير CSV"}
              </Button>
            )}
            {canEdit && <Button onClick={openNew}><Plus className="h-4 w-4 ml-1" /> عميل جديد</Button>}
          </div>
        }
      />

      <Dialog open={open} onOpenChange={(o) => { if (saving) return; setOpen(o); if (!o) { setEditingId(null); setForm(empty); } }}>
        <DialogContent
          className="max-h-[90vh] overflow-y-auto"
          onPointerDownOutside={(e) => { if (saving) e.preventDefault(); }}
          onEscapeKeyDown={(e) => { if (saving) e.preventDefault(); }}
          onInteractOutside={(e) => { if (saving) e.preventDefault(); }}
        >
          <DialogHeader><DialogTitle>{editingId ? "تعديل العميل" : "إضافة عميل"}</DialogTitle></DialogHeader>
          <form onSubmit={submit} className="space-y-3">
            <fieldset disabled={saving} className="space-y-3 disabled:opacity-70">
              <div><Label>الاسم *</Label><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><Label>اسم المحل</Label><Input value={form.shop_name} onChange={(e) => setForm({ ...form, shop_name: e.target.value })} /></div>
              <div><Label>البريد الإلكتروني</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} dir="ltr" /></div>
              <div className="grid grid-cols-2 gap-2">
                <div><Label>الهاتف</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} dir="ltr" /></div>
                <div><Label>هاتف آخر</Label><Input value={form.phone2} onChange={(e) => setForm({ ...form, phone2: e.target.value })} dir="ltr" /></div>
              </div>
              <div><Label>العنوان</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
              <div><Label>ملاحظات</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
            </fieldset>
            {formError && (
              <div className="rounded-md border border-destructive/50 bg-destructive/10 p-2 text-sm text-destructive">
                {formError}
              </div>
            )}
            <DialogFooter>
              <Button type="submit" disabled={saving}>
                {saving && <Loader2 className="h-4 w-4 ml-2 animate-spin" />}
                {saving ? "جاري الحفظ..." : editingId ? "تحديث" : "حفظ"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Card>
        <CardContent className="p-0">
          <div className="p-3 border-b">
            <div className="relative max-w-sm">
              <Search className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="بحث بالاسم أو المحل أو الهاتف..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-8"
              />
            </div>
          </div>
          {isLoading ? (
            <div className="p-4 space-y-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="flex gap-3 items-center">
                  <Skeleton className="h-8 flex-1" />
                  <Skeleton className="h-8 w-32" />
                  <Skeleton className="h-8 w-28" />
                  <Skeleton className="h-8 w-28" />
                  <Skeleton className="h-8 w-24" />
                </div>
              ))}
            </div>
          ) : data.length === 0 ? <EmptyState icon={Users} title="لا يوجد عملاء" description="أضف أول عميل لتبدأ" /> :
          filtered.length === 0 ? <div className="p-8 text-center text-muted-foreground text-sm">لا توجد نتائج مطابقة للبحث</div> :
            <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("name")}>الاسم <SortIcon k="name" /></TableHead>
                  <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("shop_name")}>اسم المحل <SortIcon k="shop_name" /></TableHead>
                  <TableHead>الهاتف</TableHead>
                  <TableHead>هاتف آخر</TableHead>
                  <TableHead>ملاحظات</TableHead>
                  <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("created_at")}>تاريخ الإضافة <SortIcon k="created_at" /></TableHead>
                  {canEdit && <TableHead></TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {paged.map((c: any) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">{c.name}</TableCell>
                    <TableCell>{c.shop_name ?? "—"}</TableCell>
                    <TableCell dir="ltr" className="text-start">{c.phone ?? "—"}</TableCell>
                    <TableCell dir="ltr" className="text-start">{c.phone2 ?? "—"}</TableCell>
                    <TableCell className="max-w-[200px] truncate" title={c.notes ?? ""}>{c.notes ?? "—"}</TableCell>
                    <TableCell>{fmtDate(c.created_at)}</TableCell>
                    {canEdit && (
                      <TableCell className="flex gap-1">
                        <Button size="icon" variant="ghost" disabled={deleting} onClick={() => openEdit(c)}><Pencil className="h-4 w-4" /></Button>
                        <Button size="icon" variant="ghost" disabled={deleting} onClick={() => setDeleteId(c.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="flex items-center justify-between border-t px-3 py-2 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <span>عدد الصفوف:</span>
                <Select value={String(pageSize)} onValueChange={(v) => { setPageSize(Number(v)); setPage(1); }}>
                  <SelectTrigger className="h-8 w-16">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PAGE_SIZE_OPTIONS.map((n) => (
                      <SelectItem key={n} value={String(n)}>{n}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">صفحة {safePage} من {totalPages} ({filtered.length} إجمالي)</span>
                <div className="flex gap-1">
                  <Button size="icon" variant="outline" className="h-8 w-8" disabled={safePage <= 1} onClick={() => setPage(1)}><ChevronsLeft className="h-4 w-4" /></Button>
                  <Button size="icon" variant="outline" className="h-8 w-8" disabled={safePage <= 1} onClick={() => setPage(safePage - 1)}><ChevronLeft className="h-4 w-4" /></Button>
                  <Button size="icon" variant="outline" className="h-8 w-8" disabled={safePage >= totalPages} onClick={() => setPage(safePage + 1)}><ChevronRight className="h-4 w-4" /></Button>
                  <Button size="icon" variant="outline" className="h-8 w-8" disabled={safePage >= totalPages} onClick={() => setPage(totalPages)}><ChevronsRight className="h-4 w-4" /></Button>
                </div>
              </div>
            </div>
            </>
          }
        </CardContent>
      </Card>

      <Dialog open={exportOpen} onOpenChange={(o) => { if (exporting) return; setExportOpen(o); }}>
        <DialogContent
          onPointerDownOutside={(e) => { if (exporting) e.preventDefault(); }}
          onEscapeKeyDown={(e) => { if (exporting) e.preventDefault(); }}
        >
          <DialogHeader><DialogTitle>اختر الأعمدة للتصدير</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <Label className="text-xs">نطاق التصدير</Label>
            <Select value={exportScope} onValueChange={(v) => setExportScope(v as "all" | "page")} disabled={exporting}>
              <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل النتائج ({filtered.length})</SelectItem>
                <SelectItem value="page">الصفحة الحالية ({paged.length})</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-2 py-2">
            {ALL_COLS.map((c) => (
              <label key={c.key} className="flex items-center gap-2 text-sm cursor-pointer">
                <Checkbox
                  checked={selectedCols.includes(c.key)}
                  onCheckedChange={(v) => {
                    setSelectedCols((prev) => v ? [...prev, c.key] : prev.filter((k) => k !== c.key));
                  }}
                  disabled={exporting}
                />
                {c.label}
              </label>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setExportOpen(false)} disabled={exporting}>إلغاء</Button>
            <Button onClick={runExport} disabled={exporting || selectedCols.length === 0}>
              {exporting && <Loader2 className="h-4 w-4 ml-2 animate-spin" />}
              {exporting ? "جاري التصدير..." : "تصدير"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => { if (deleting) return; if (!o) setDeleteId(null); }}>
        <AlertDialogContent
          onEscapeKeyDown={(e) => { if (deleting) e.preventDefault(); }}
        >
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف هذا العميل؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={(e) => { e.preventDefault(); confirmDelete(); }} disabled={deleting}>
              {deleting && <Loader2 className="h-4 w-4 ml-2 animate-spin" />}
              {deleting ? "جاري الحذف..." : "حذف"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
