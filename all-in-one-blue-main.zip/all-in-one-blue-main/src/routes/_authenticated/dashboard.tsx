import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { StatCard } from "@/components/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, FileText, Package, Wallet, TrendingUp, ShoppingCart } from "lucide-react";
import { fmtMoney, fmtDate } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: Dashboard,
});

function Dashboard() {
  const { user } = useAuth();
  const { data: stats } = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: async () => {
      const [c, s, p, inv, emp] = await Promise.all([
        supabase.from("customers").select("*", { count: "exact", head: true }),
        supabase.from("suppliers").select("*", { count: "exact", head: true }),
        supabase.from("products").select("*", { count: "exact", head: true }),
        supabase.from("invoices").select("total"),
        supabase.from("employees").select("*", { count: "exact", head: true }),
      ]);
      const totalSales = (inv.data ?? []).reduce((sum, r) => sum + Number(r.total), 0);
      return {
        customers: c.count ?? 0,
        suppliers: s.count ?? 0,
        products: p.count ?? 0,
        employees: emp.count ?? 0,
        invoiceCount: inv.data?.length ?? 0,
        totalSales,
      };
    },
  });

  const { data: recentInvoices } = useQuery({
    queryKey: ["recent-invoices"],
    queryFn: async () => {
      const { data } = await supabase
        .from("invoices")
        .select("id, invoice_number, total, status, issue_date, customers(name)")
        .order("created_at", { ascending: false })
        .limit(5);
      return data ?? [];
    },
  });

  return (
    <>
      <PageHeader
        title={`أهلاً، ${user?.email?.split("@")[0] ?? ""}`}
        description="نظرة عامة على أداء مؤسستك"
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard title="إجمالي المبيعات" value={fmtMoney(stats?.totalSales ?? 0)} icon={TrendingUp} color="success" />
        <StatCard title="الفواتير" value={String(stats?.invoiceCount ?? 0)} icon={FileText} />
        <StatCard title="العملاء" value={String(stats?.customers ?? 0)} icon={Users} />
        <StatCard title="الموردون" value={String(stats?.suppliers ?? 0)} icon={ShoppingCart} color="warning" />
        <StatCard title="المنتجات" value={String(stats?.products ?? 0)} icon={Package} />
        <StatCard title="الموظفون" value={String(stats?.employees ?? 0)} icon={Wallet} color="success" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>أحدث الفواتير</CardTitle>
        </CardHeader>
        <CardContent>
          {(!recentInvoices || recentInvoices.length === 0) ? (
            <p className="text-sm text-muted-foreground text-center py-8">لا توجد فواتير بعد. ابدأ بإنشاء فاتورة جديدة.</p>
          ) : (
            <div className="space-y-3">
              {recentInvoices.map((inv: any) => (
                <div key={inv.id} className="flex items-center justify-between border-b pb-3 last:border-b-0 last:pb-0">
                  <div>
                    <div className="font-medium">{inv.invoice_number}</div>
                    <div className="text-xs text-muted-foreground">{inv.customers?.name ?? "—"} · {fmtDate(inv.issue_date)}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-bold">{fmtMoney(inv.total)}</span>
                    <Badge variant={inv.status === "paid" ? "default" : "secondary"}>
                      {inv.status === "paid" ? "مدفوعة" : inv.status === "draft" ? "مسودة" : "معلقة"}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}