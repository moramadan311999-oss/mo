import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Plus, Wallet, Check } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { fmtMoney } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/payroll")({ component: Payroll });

function Payroll() {
  const qc = useQueryClient();
  const { user, hasAnyRole } = useAuth();
  const canEdit = !!user && hasAnyRole(["admin", "hr", "accountant"]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ employee_id: "", pay_period: "", base_salary: "0", bonuses: "0", deductions: "0" });

  const { data = [] } = useQuery({
    queryKey: ["payroll"],
    queryFn: async () => (await supabase.from("payroll").select("*, employees(full_name)").order("created_at", { ascending: false })).data ?? [],
  });
  const { data: employees = [] } = useQuery({
    queryKey: ["employees-list"],
    queryFn: async () => (await supabase.from("employees").select("id, full_name, base_salary")).data ?? [],
  });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const base = Number(form.base_salary), bon = Number(form.bonuses), ded = Number(form.deductions);
    const { error } = await supabase.from("payroll").insert({
      employee_id: form.employee_id, pay_period: form.pay_period,
      base_salary: base, bonuses: bon, deductions: ded, net_salary: base + bon - ded,
    });
    if (error) return toast.error(error.message);
    toast.success("تمت الإضافة");
    setOpen(false);
    setForm({ employee_id: "", pay_period: "", base_salary: "0", bonuses: "0", deductions: "0" });
    qc.invalidateQueries({ queryKey: ["payroll"] });
  };

  const markPaid = async (id: string) => {
    await supabase.from("payroll").update({ paid: true, paid_at: new Date().toISOString() }).eq("id", id);
    toast.success("تم تسجيل الدفع");
    qc.invalidateQueries({ queryKey: ["payroll"] });
  };

  return (
    <>
      <PageHeader title="الرواتب" description="إدارة وصرف الرواتب" action={canEdit && (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 ml-1" /> سجل راتب</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>إضافة سجل راتب</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <div>
                <Label>الموظف</Label>
                <Select value={form.employee_id} onValueChange={(v) => {
                  const emp = employees.find((e: any) => e.id === v);
                  setForm({ ...form, employee_id: v, base_salary: emp?.base_salary?.toString() ?? "0" });
                }}>
                  <SelectTrigger><SelectValue placeholder="اختر موظفاً" /></SelectTrigger>
                  <SelectContent>{employees.map((e: any) => <SelectItem key={e.id} value={e.id}>{e.full_name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>الفترة (مثال: 2026-05)</Label><Input required value={form.pay_period} onChange={(e) => setForm({ ...form, pay_period: e.target.value })} dir="ltr" placeholder="2026-05" /></div>
              <div className="grid grid-cols-3 gap-2">
                <div><Label>الأساسي</Label><Input type="number" step="0.01" value={form.base_salary} onChange={(e) => setForm({ ...form, base_salary: e.target.value })} /></div>
                <div><Label>البدلات</Label><Input type="number" step="0.01" value={form.bonuses} onChange={(e) => setForm({ ...form, bonuses: e.target.value })} /></div>
                <div><Label>الخصومات</Label><Input type="number" step="0.01" value={form.deductions} onChange={(e) => setForm({ ...form, deductions: e.target.value })} /></div>
              </div>
              <DialogFooter><Button type="submit">حفظ</Button></DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      )} />
      <Card><CardContent className="p-0">
        {data.length === 0 ? <EmptyState icon={Wallet} title="لا توجد سجلات رواتب" /> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الموظف</TableHead><TableHead>الفترة</TableHead><TableHead>الأساسي</TableHead><TableHead>البدلات</TableHead><TableHead>الخصومات</TableHead><TableHead>الصافي</TableHead><TableHead>الحالة</TableHead>
              {canEdit && <TableHead></TableHead>}
            </TableRow></TableHeader>
            <TableBody>
              {data.map((p: any) => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.employees?.full_name ?? "—"}</TableCell>
                  <TableCell dir="ltr">{p.pay_period}</TableCell>
                  <TableCell>{fmtMoney(p.base_salary)}</TableCell>
                  <TableCell className="text-success">{fmtMoney(p.bonuses)}</TableCell>
                  <TableCell className="text-destructive">{fmtMoney(p.deductions)}</TableCell>
                  <TableCell className="font-bold">{fmtMoney(p.net_salary)}</TableCell>
                  <TableCell><Badge variant={p.paid ? "default" : "secondary"}>{p.paid ? "مدفوع" : "معلق"}</Badge></TableCell>
                  {canEdit && <TableCell>{!p.paid && <Button size="sm" variant="ghost" onClick={() => markPaid(p.id)}><Check className="h-4 w-4 ml-1" /> دفع</Button>}</TableCell>}
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent></Card>
    </>
  );
}
