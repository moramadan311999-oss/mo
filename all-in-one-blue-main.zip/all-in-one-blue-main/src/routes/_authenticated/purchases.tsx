import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Plus, ShoppingCart, Trash2, Eye, Pencil } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { fmtMoney, fmtDate } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/purchases")({ component: Purchases });

type LineItem = { id?: string; product_id: string | null; description: string; quantity: number; unit_cost: number };
const emptyLine = (): LineItem => ({ product_id: null, description: "", quantity: 1, unit_cost: 0 });

function Purchases() {
  const qc = useQueryClient();
  const { user, hasAnyRole } = useAuth();
  const canEdit = !!user && hasAnyRole(["admin", "manager"]);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [viewId, setViewId] = useState<string | null>(null);
  const [supplierId, setSupplierId] = useState("");
  const [status, setStatus] = useState("pending");
  const [notes, setNotes] = useState("");
  const [lines, setLines] = useState<LineItem[]>([emptyLine()]);

  const { data: orders = [] } = useQuery({
    queryKey: ["purchase_orders"],
    queryFn: async () => (await supabase.from("purchase_orders").select("*, suppliers(name)").order("created_at", { ascending: false })).data ?? [],
  });
  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers-list"],
    queryFn: async () => (await supabase.from("suppliers").select("id, name")).data ?? [],
  });
  const { data: products = [] } = useQuery({
    queryKey: ["products-list"],
    queryFn: async () => (await supabase.from("products").select("id, name, cost, price")).data ?? [],
  });

  const total = useMemo(
    () => lines.reduce((s, l) => s + (Number(l.quantity) || 0) * (Number(l.unit_cost) || 0), 0),
    [lines],
  );

  const reset = () => { setEditingId(null); setSupplierId(""); setStatus("pending"); setNotes(""); setLines([emptyLine()]); };
  const openNew = () => { reset(); setEditorOpen(true); };
  const openEdit = async (o: any) => {
    setEditingId(o.id); setSupplierId(o.supplier_id ?? ""); setStatus(o.status); setNotes(o.notes ?? "");
    const { data } = await supabase.from("purchase_order_items").select("*").eq("purchase_order_id", o.id);
    setLines((data ?? []).length ? (data ?? []).map((it: any) => ({
      id: it.id, product_id: it.product_id, description: it.description,
      quantity: Number(it.quantity), unit_cost: Number(it.unit_cost),
    })) : [emptyLine()]);
    setEditorOpen(true);
  };

  const updateLine = (i: number, patch: Partial<LineItem>) => setLines((p) => p.map((l, idx) => idx === i ? { ...l, ...patch } : l));
  const onPickProduct = (i: number, pid: string) => {
    const p: any = products.find((x: any) => x.id === pid);
    if (!p) return;
    updateLine(i, { product_id: p.id, description: p.name, unit_cost: Number(p.cost ?? p.price ?? 0) });
  };
  const addLine = () => setLines((p) => [...p, emptyLine()]);
  const removeLine = (i: number) => setLines((p) => p.length === 1 ? [emptyLine()] : p.filter((_, idx) => idx !== i));

  const save = async () => {
    const valid = lines.filter((l) => l.description.trim() && Number(l.quantity) > 0);
    if (!valid.length) return toast.error("أضف صنفاً واحداً على الأقل");
    if (!supplierId) return toast.error("اختر المورد");

    const payload = { supplier_id: supplierId, total, status, notes: notes || null };
    let poId = editingId;
    if (editingId) {
      const { error } = await supabase.from("purchase_orders").update(payload).eq("id", editingId);
      if (error) return toast.error(error.message);
      await supabase.from("purchase_order_items").delete().eq("purchase_order_id", editingId);
    } else {
      const { data, error } = await supabase.from("purchase_orders")
        .insert({ ...payload, po_number: `PO-${Date.now()}` }).select("id").single();
      if (error || !data) return toast.error(error?.message ?? "خطأ");
      poId = data.id;
    }
    const items = valid.map((l) => ({
      purchase_order_id: poId!, product_id: l.product_id, description: l.description,
      quantity: l.quantity, unit_cost: l.unit_cost, total: l.quantity * l.unit_cost,
    }));
    const { error: itemsErr } = await supabase.from("purchase_order_items").insert(items);
    if (itemsErr) return toast.error(itemsErr.message);
    toast.success(editingId ? "تم تحديث أمر الشراء" : "تم إنشاء أمر الشراء");
    setEditorOpen(false); reset();
    qc.invalidateQueries({ queryKey: ["purchase_orders"] });
  };

  const remove = async (id: string) => {
    if (!confirm("حذف؟")) return;
    await supabase.from("purchase_order_items").delete().eq("purchase_order_id", id);
    await supabase.from("purchase_orders").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["purchase_orders"] });
  };

  const sl = (s: string) => s === "received" ? "مستلم" : s === "pending" ? "معلق" : s === "approved" ? "معتمد" : "ملغي";

  return (
    <>
      <PageHeader title="فواتير المشتريات" description="إدارة أوامر الشراء مع الأصناف والمورد"
        action={canEdit && <Button onClick={openNew}><Plus className="h-4 w-4 ml-1" /> أمر شراء جديد</Button>} />

      <Dialog open={editorOpen} onOpenChange={(o) => { setEditorOpen(o); if (!o) reset(); }}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingId ? "تعديل أمر الشراء" : "إنشاء أمر شراء"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>المورد *</Label>
                <Select value={supplierId} onValueChange={setSupplierId}>
                  <SelectTrigger><SelectValue placeholder="اختر مورداً" /></SelectTrigger>
                  <SelectContent>{suppliers.map((s: any) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>الحالة</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">معلق</SelectItem>
                    <SelectItem value="approved">معتمد</SelectItem>
                    <SelectItem value="received">مستلم</SelectItem>
                    <SelectItem value="cancelled">ملغي</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <Label>الأصناف</Label>
                <Button type="button" size="sm" variant="outline" onClick={addLine}><Plus className="h-4 w-4 ml-1" /> إضافة صنف</Button>
              </div>
              <div className="border rounded-md overflow-x-auto">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead className="min-w-[140px]">المنتج</TableHead>
                    <TableHead className="min-w-[160px]">الوصف</TableHead>
                    <TableHead className="w-24">الكمية</TableHead>
                    <TableHead className="w-28">التكلفة</TableHead>
                    <TableHead className="w-28">الإجمالي</TableHead>
                    <TableHead className="w-12"></TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {lines.map((l, i) => (
                      <TableRow key={i}>
                        <TableCell>
                          <Select value={l.product_id ?? ""} onValueChange={(v) => onPickProduct(i, v)}>
                            <SelectTrigger className="h-8"><SelectValue placeholder="—" /></SelectTrigger>
                            <SelectContent>{products.map((p: any) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell><Input className="h-8" value={l.description} onChange={(e) => updateLine(i, { description: e.target.value })} /></TableCell>
                        <TableCell><Input className="h-8" type="number" min="0" step="1" value={l.quantity} onChange={(e) => updateLine(i, { quantity: Number(e.target.value) })} /></TableCell>
                        <TableCell><Input className="h-8" type="number" min="0" step="0.01" value={l.unit_cost} onChange={(e) => updateLine(i, { unit_cost: Number(e.target.value) })} /></TableCell>
                        <TableCell className="font-medium">{fmtMoney(l.quantity * l.unit_cost)}</TableCell>
                        <TableCell><Button size="icon" variant="ghost" type="button" onClick={() => removeLine(i)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div><Label>ملاحظات</Label><Input value={notes} onChange={(e) => setNotes(e.target.value)} /></div>
              <div className="text-sm bg-muted/50 rounded-md p-3 flex justify-between items-center font-bold">
                <span>الإجمالي</span><span>{fmtMoney(total)}</span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditorOpen(false)}>إلغاء</Button>
            <Button onClick={save}>{editingId ? "تحديث" : "حفظ"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Card><CardContent className="p-0">
        {orders.length === 0 ? <EmptyState icon={ShoppingCart} title="لا توجد أوامر شراء" /> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الرقم</TableHead><TableHead>المورد</TableHead><TableHead>التاريخ</TableHead><TableHead>الإجمالي</TableHead><TableHead>الحالة</TableHead>
              <TableHead></TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {orders.map((o: any) => (
                <TableRow key={o.id}>
                  <TableCell className="font-mono text-sm" dir="ltr">{o.po_number}</TableCell>
                  <TableCell>{o.suppliers?.name ?? "—"}</TableCell>
                  <TableCell>{fmtDate(o.order_date)}</TableCell>
                  <TableCell className="font-bold">{fmtMoney(o.total)}</TableCell>
                  <TableCell><Badge variant={o.status === "received" ? "default" : "secondary"}>{sl(o.status)}</Badge></TableCell>
                  <TableCell className="flex gap-1">
                    <Button size="icon" variant="ghost" onClick={() => setViewId(o.id)}><Eye className="h-4 w-4" /></Button>
                    {canEdit && <>
                      <Button size="icon" variant="ghost" onClick={() => openEdit(o)}><Pencil className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => remove(o.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                    </>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent></Card>

      <PurchaseViewer id={viewId} onClose={() => setViewId(null)} />
    </>
  );
}

function PurchaseViewer({ id, onClose }: { id: string | null; onClose: () => void }) {
  const { data } = useQuery({
    queryKey: ["po-detail", id],
    enabled: !!id,
    queryFn: async () => {
      const [{ data: po }, { data: items }] = await Promise.all([
        supabase.from("purchase_orders").select("*, suppliers(name)").eq("id", id!).single(),
        supabase.from("purchase_order_items").select("*").eq("purchase_order_id", id!),
      ]);
      return { po, items: items ?? [] };
    },
  });
  return (
    <Dialog open={!!id} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader><DialogTitle>تفاصيل أمر الشراء {data?.po?.po_number}</DialogTitle></DialogHeader>
        {data?.po && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><span className="text-muted-foreground">المورد: </span>{data.po.suppliers?.name ?? "—"}</div>
              <div><span className="text-muted-foreground">التاريخ: </span>{fmtDate(data.po.order_date)}</div>
            </div>
            <Table>
              <TableHeader><TableRow><TableHead>الوصف</TableHead><TableHead>الكمية</TableHead><TableHead>التكلفة</TableHead><TableHead>الإجمالي</TableHead></TableRow></TableHeader>
              <TableBody>
                {data.items.map((it: any) => (
                  <TableRow key={it.id}>
                    <TableCell>{it.description}</TableCell>
                    <TableCell>{it.quantity}</TableCell>
                    <TableCell>{fmtMoney(it.unit_cost)}</TableCell>
                    <TableCell className="font-medium">{fmtMoney(it.total)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="flex justify-between font-bold border-t pt-2"><span>الإجمالي</span><span>{fmtMoney(data.po.total)}</span></div>
            {data.po.notes && <div className="text-sm"><span className="text-muted-foreground">ملاحظات: </span>{data.po.notes}</div>}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
