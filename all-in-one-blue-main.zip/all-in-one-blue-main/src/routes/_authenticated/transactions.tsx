import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Receipt, Trash2, Loader2 } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { fmtMoney, fmtDate } from "@/lib/format";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/transactions")({ component: TransactionsPage });

type FormState = {
  type: "receipt" | "payment";
  amount: string;
  method: "cash" | "bank" | "card" | "other";
  party_name: string;
  invoice_id: string;
  purchase_order_id: string;
  transaction_date: string;
  notes: string;
};

const today = () => new Date().toISOString().slice(0, 10);
const empty: FormState = {
  type: "receipt", amount: "0", method: "cash", party_name: "",
  invoice_id: "", purchase_order_id: "", transaction_date: today(), notes: "",
};

function TransactionsPage() {
  const qc = useQueryClient();
  const { user, hasAnyRole } = useAuth();
  const canEdit = !!user && hasAnyRole(["admin", "manager", "accountant"]);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<FormState>(empty);
  const [filter, setFilter] = useState<"all" | "receipt" | "payment">("all");

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["transactions"],
    queryFn: async () => (await supabase.from("transactions")
      .select("*, invoices(invoice_number), purchase_orders(po_number)")
      .order("transaction_date", { ascending: false })).data ?? [],
  });
  const { data: invoices = [] } = useQuery({
    queryKey: ["invoices-list"],
    queryFn: async () => (await supabase.from("invoices").select("id, invoice_number, total")).data ?? [],
  });
  const { data: pos = [] } = useQuery({
    queryKey: ["pos-list"],
    queryFn: async () => (await supabase.from("purchase_orders").select("id, po_number, total")).data ?? [],
  });

  const visible = useMemo(
    () => filter === "all" ? rows : rows.filter((r: any) => r.type === filter),
    [rows, filter],
  );

  const totals = useMemo(() => {
    let inAmt = 0, outAmt = 0;
    for (const r of rows as any[]) {
      if (r.type === "receipt") inAmt += Number(r.amount);
      else outAmt += Number(r.amount);
    }
    return { in: inAmt, out: outAmt, net: inAmt - outAmt };
  }, [rows]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    try {
      const prefix = form.type === "receipt" ? "RC" : "PV";
      const payload = {
        voucher_number: `${prefix}-${Date.now()}`,
        type: form.type,
        amount: Number(form.amount),
        method: form.method,
        invoice_id: form.type === "receipt" && form.invoice_id ? form.invoice_id : null,
        purchase_order_id: form.type === "payment" && form.purchase_order_id ? form.purchase_order_id : null,
        party_name: form.party_name || null,
        notes: form.notes || null,
        transaction_date: form.transaction_date,
      };
      const { error } = await supabase.from("transactions").insert(payload);
      if (error) { toast.error("فشل حفظ السند", { description: error.message }); return; }
      toast.success(form.type === "receipt" ? "تم إنشاء سند القبض" : "تم إنشاء سند الصرف");
      setOpen(false);
      setForm(empty);
      qc.invalidateQueries({ queryKey: ["transactions"] });
    } finally { setSaving(false); }
  };

  const remove = async (id: string) => {
    if (!confirm("حذف السند؟")) return;
    const { error } = await supabase.from("transactions").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("تم الحذف");
    qc.invalidateQueries({ queryKey: ["transactions"] });
  };

  return (
    <>
      <PageHeader
        title="سندات القبض والصرف"
        description="المعاملات المالية المرتبطة بفواتير المبيعات والمشتريات"
        action={canEdit && <Button onClick={() => { setForm(empty); setOpen(true); }}><Plus className="h-4 w-4 ml-1" /> سند جديد</Button>}
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">إجمالي المقبوضات</div><div className="text-xl font-bold text-green-600">{fmtMoney(totals.in)}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">إجمالي المدفوعات</div><div className="text-xl font-bold text-destructive">{fmtMoney(totals.out)}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">الصافي</div><div className="text-xl font-bold">{fmtMoney(totals.net)}</div></CardContent></Card>
      </div>

      <Dialog open={open} onOpenChange={(o) => { if (saving) return; setOpen(o); }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form.type === "receipt" ? "سند قبض" : "سند صرف"}</DialogTitle></DialogHeader>
          <form onSubmit={submit} className="space-y-3">
            <fieldset disabled={saving} className="space-y-3 disabled:opacity-70">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>نوع السند</Label>
                  <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as any, invoice_id: "", purchase_order_id: "" })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="receipt">سند قبض (مبيعات)</SelectItem>
                      <SelectItem value="payment">سند صرف (مشتريات)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>طريقة الدفع</Label>
                  <Select value={form.method} onValueChange={(v) => setForm({ ...form, method: v as any })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">نقدي</SelectItem>
                      <SelectItem value="bank">تحويل بنكي</SelectItem>
                      <SelectItem value="card">بطاقة</SelectItem>
                      <SelectItem value="other">أخرى</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div><Label>المبلغ *</Label><Input required type="number" min="0" step="0.01" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
                <div><Label>التاريخ</Label><Input type="date" value={form.transaction_date} onChange={(e) => setForm({ ...form, transaction_date: e.target.value })} /></div>
              </div>
              {form.type === "receipt" ? (
                <div>
                  <Label>فاتورة المبيعات (اختياري)</Label>
                  <Select value={form.invoice_id || "none"} onValueChange={(v) => setForm({ ...form, invoice_id: v === "none" ? "" : v })}>
                    <SelectTrigger><SelectValue placeholder="بدون ربط" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">بدون ربط</SelectItem>
                      {invoices.map((i: any) => <SelectItem key={i.id} value={i.id}>{i.invoice_number} — {fmtMoney(i.total)}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              ) : (
                <div>
                  <Label>أمر الشراء (اختياري)</Label>
                  <Select value={form.purchase_order_id || "none"} onValueChange={(v) => setForm({ ...form, purchase_order_id: v === "none" ? "" : v })}>
                    <SelectTrigger><SelectValue placeholder="بدون ربط" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">بدون ربط</SelectItem>
                      {pos.map((p: any) => <SelectItem key={p.id} value={p.id}>{p.po_number} — {fmtMoney(p.total)}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div><Label>اسم الطرف</Label><Input value={form.party_name} onChange={(e) => setForm({ ...form, party_name: e.target.value })} placeholder="العميل / المورد" /></div>
              <div><Label>ملاحظات</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
            </fieldset>
            <DialogFooter>
              <Button type="submit" disabled={saving}>
                {saving && <Loader2 className="h-4 w-4 ml-2 animate-spin" />}
                {saving ? "جاري الحفظ..." : "حفظ"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Card>
        <CardContent className="p-0">
          <div className="p-3 border-b flex items-center gap-2">
            <Label className="text-xs">تصفية:</Label>
            <Select value={filter} onValueChange={(v) => setFilter(v as any)}>
              <SelectTrigger className="h-8 w-40"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الكل</SelectItem>
                <SelectItem value="receipt">سندات قبض</SelectItem>
                <SelectItem value="payment">سندات صرف</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {isLoading ? <div className="p-6 text-center text-sm text-muted-foreground">جاري التحميل...</div> :
            visible.length === 0 ? <EmptyState icon={Receipt} title="لا توجد سندات" description="ابدأ بإنشاء أول سند قبض أو صرف" /> :
            <Table>
              <TableHeader><TableRow>
                <TableHead>الرقم</TableHead>
                <TableHead>النوع</TableHead>
                <TableHead>المبلغ</TableHead>
                <TableHead>طريقة الدفع</TableHead>
                <TableHead>المستند</TableHead>
                <TableHead>الطرف</TableHead>
                <TableHead>التاريخ</TableHead>
                {canEdit && <TableHead></TableHead>}
              </TableRow></TableHeader>
              <TableBody>
                {visible.map((r: any) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-mono text-sm" dir="ltr">{r.voucher_number}</TableCell>
                    <TableCell><Badge variant={r.type === "receipt" ? "default" : "destructive"}>{r.type === "receipt" ? "قبض" : "صرف"}</Badge></TableCell>
                    <TableCell className="font-bold">{fmtMoney(r.amount)}</TableCell>
                    <TableCell>{({ cash: "نقدي", bank: "بنكي", card: "بطاقة", other: "أخرى" } as any)[r.method] ?? r.method}</TableCell>
                    <TableCell className="font-mono text-xs" dir="ltr">{r.invoices?.invoice_number ?? r.purchase_orders?.po_number ?? "—"}</TableCell>
                    <TableCell>{r.party_name ?? "—"}</TableCell>
                    <TableCell>{fmtDate(r.transaction_date)}</TableCell>
                    {canEdit && <TableCell><Button size="icon" variant="ghost" onClick={() => remove(r.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          }
        </CardContent>
      </Card>
    </>
  );
}