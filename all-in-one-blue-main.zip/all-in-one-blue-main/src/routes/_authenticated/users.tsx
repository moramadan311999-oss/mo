import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Shield, X } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useAuth, ROLE_LABELS, type AppRole } from "@/lib/auth-context";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/users")({ component: UsersPage });

const ROLES: AppRole[] = ["admin", "manager", "accountant", "hr", "employee"];

function UsersPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { hasRole, loading } = useAuth();
  const isAdmin = hasRole("admin");

  useEffect(() => {
    if (!loading && !isAdmin) {
      toast.error("هذه الصفحة للمدراء فقط");
      navigate({ to: "/dashboard" });
    }
  }, [isAdmin, loading, navigate]);

  const { data = [] } = useQuery({
    queryKey: ["users-list"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data: profiles } = await supabase.from("profiles").select("*");
      const { data: roles } = await supabase.from("user_roles").select("*");
      return (profiles ?? []).map((p) => ({
        ...p,
        roles: (roles ?? []).filter((r) => r.user_id === p.id).map((r) => r.role as AppRole),
      }));
    },
  });

  const addRole = async (userId: string, role: AppRole) => {
    const { error } = await supabase.from("user_roles").insert({ user_id: userId, role });
    if (error) return toast.error(error.message);
    toast.success("تمت إضافة الصلاحية");
    qc.invalidateQueries({ queryKey: ["users-list"] });
  };

  const removeRole = async (userId: string, role: AppRole) => {
    const { error } = await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", role);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["users-list"] });
  };

  if (loading || !isAdmin) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      <PageHeader title="المستخدمون والصلاحيات" description="إدارة أدوار المستخدمين" />
      <Card><CardContent className="p-0">
        {data.length === 0 ? <EmptyState icon={Shield} title="لا يوجد مستخدمون" /> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الاسم</TableHead><TableHead>الصلاحيات الحالية</TableHead><TableHead>إضافة صلاحية</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {data.map((u: any) => {
                const available = ROLES.filter((r) => !u.roles.includes(r));
                return (
                  <TableRow key={u.id}>
                    <TableCell className="font-medium">{u.full_name || "—"}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {u.roles.length === 0 ? <span className="text-muted-foreground text-sm">لا توجد</span> :
                          u.roles.map((r: AppRole) => (
                            <Badge key={r} variant="secondary" className="gap-1">
                              {ROLE_LABELS[r]}
                              <button onClick={() => removeRole(u.id, r)} className="hover:text-destructive">
                                <X className="h-3 w-3" />
                              </button>
                            </Badge>
                          ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      {available.length > 0 && (
                        <Select onValueChange={(v) => addRole(u.id, v as AppRole)}>
                          <SelectTrigger className="w-40"><SelectValue placeholder="إضافة..." /></SelectTrigger>
                          <SelectContent>
                            {available.map((r) => <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>}
      </CardContent></Card>
    </>
  );
}
