import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useMemo, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Plus, FileText, Trash2, Eye, Pencil } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { fmtMoney, fmtDate } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/invoices")({ component: Invoices });

type LineItem = {
  id?: string;
  product_id: string | null;
  description: string;
  quantity: number;
  unit_price: number;
};

const TAX_RATE = 0.15;
const emptyLine = (): LineItem => ({ product_id: null, description: "", quantity: 1, unit_price: 0 });

function Invoices() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const canEdit = !!user;
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [viewId, setViewId] = useState<string | null>(null);
  const [customerId, setCustomerId] = useState<string>("");
  const [status, setStatus] = useState<string>("draft");
  const [notes, setNotes] = useState("");
  const [lines, setLines] = useState<LineItem[]>([emptyLine()]);

  const { data: invoices = [] } = useQuery({
    queryKey: ["invoices"],
    queryFn: async () => (await supabase.from("invoices").select("*, customers(name)").order("created_at", { ascending: false })).data ?? [],
  });
  const { data: customers = [] } = useQuery({
    queryKey: ["customers-list"],
    queryFn: async () => (await supabase.from("customers").select("id, name")).data ?? [],
  });
  const { data: products = [] } = useQuery({
    queryKey: ["products-list"],
    queryFn: async () => (await supabase.from("products").select("id, name, price")).data ?? [],
  });

  const totals = useMemo(() => {
    const subtotal = lines.reduce((s, l) => s + (Number(l.quantity) || 0) * (Number(l.unit_price) || 0), 0);
    const tax = subtotal * TAX_RATE;
    return { subtotal, tax, total: subtotal + tax };
  }, [lines]);

  const resetEditor = () => {
    setEditingId(null);
    setCustomerId("");
    setStatus("draft");
    setNotes("");
    setLines([emptyLine()]);
  };

  const openNew = () => {
    resetEditor();
    setEditorOpen(true);
  };

  const openEdit = async (inv: any) => {
    setEditingId(inv.id);
    setCustomerId(inv.customer_id ?? "");
    setStatus(inv.status);
    setNotes(inv.notes ?? "");
    const { data } = await supabase.from("invoice_items").select("*").eq("invoice_id", inv.id);
    setLines((data ?? []).length ? (data ?? []).map((it: any) => ({
      id: it.id, product_id: it.product_id, description: it.description,
      quantity: Number(it.quantity), unit_price: Number(it.unit_price),
    })) : [emptyLine()]);
    setEditorOpen(true);
  };

  const updateLine = (i: number, patch: Partial<LineItem>) => {
    setLines((prev) => prev.map((l, idx) => idx === i ? { ...l, ...patch } : l));
  };

  const onPickProduct = (i: number, productId: string) => {
    const p: any = products.find((x: any) => x.id === productId);
    if (!p) return;
    updateLine(i, { product_id: p.id, description: p.name, unit_price: Number(p.price) });
  };

  const addLine = () => setLines((p) => [...p, emptyLine()]);
  const removeLine = (i: number) => setLines((p) => p.length === 1 ? [emptyLine()] : p.filter((_, idx) => idx !== i));

  const save = async () => {
    const valid = lines.filter((l) => l.description.trim() && Number(l.quantity) > 0);
    if (!valid.length) return toast.error("أضف بنداً واحداً على الأقل");

    const payload = {
      customer_id: customerId || null,
      subtotal: totals.subtotal,
      tax: totals.tax,
      total: totals.total,
      status, notes: notes || null,
    };

    let invoiceId = editingId;
    if (editingId) {
      const { error } = await supabase.from("invoices").update(payload).eq("id", editingId);
      if (error) return toast.error(error.message);
      await supabase.from("invoice_items").delete().eq("invoice_id", editingId);
    } else {
      const { data, error } = await supabase.from("invoices").insert({
        ...payload, invoice_number: `INV-${Date.now()}`,
      }).select("id").single();
      if (error || !data) return toast.error(error?.message ?? "خطأ");
      invoiceId = data.id;
    }

    const itemsPayload = valid.map((l) => ({
      invoice_id: invoiceId!,
      product_id: l.product_id,
      description: l.description,
      quantity: l.quantity,
      unit_price: l.unit_price,
      total: l.quantity * l.unit_price,
    }));
    const { error: itemsErr } = await supabase.from("invoice_items").insert(itemsPayload);
    if (itemsErr) return toast.error(itemsErr.message);

    toast.success(editingId ? "تم تحديث الفاتورة" : "تم إنشاء الفاتورة");
    setEditorOpen(false);
    resetEditor();
    qc.invalidateQueries({ queryKey: ["invoices"] });
  };

  const remove = async (id: string) => {
    if (!confirm("حذف الفاتورة وبنودها؟")) return;
    await supabase.from("invoice_items").delete().eq("invoice_id", id);
    await supabase.from("invoices").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["invoices"] });
  };

  const statusLabel = (s: string) => s === "paid" ? "مدفوعة" : s === "draft" ? "مسودة" : s === "sent" ? "مرسلة" : "ملغاة";

  return (
    <>
      <PageHeader title="الفواتير" description="إدارة فواتير المبيعات مع البنود التفصيلية" action={canEdit && (
        <Button onClick={openNew}><Plus className="h-4 w-4 ml-1" /> فاتورة جديدة</Button>
      )} />

      <Card><CardContent className="p-0">
        {invoices.length === 0 ? <EmptyState icon={FileText} title="لا توجد فواتير" description="ابدأ بإنشاء أول فاتورة" /> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الرقم</TableHead><TableHead>العميل</TableHead><TableHead>التاريخ</TableHead>
              <TableHead>الإجمالي</TableHead><TableHead>الحالة</TableHead><TableHead></TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {invoices.map((i: any) => (
                <TableRow key={i.id}>
                  <TableCell className="font-mono text-sm" dir="ltr">{i.invoice_number}</TableCell>
                  <TableCell>{i.customers?.name ?? "—"}</TableCell>
                  <TableCell>{fmtDate(i.issue_date)}</TableCell>
                  <TableCell className="font-bold">{fmtMoney(i.total)}</TableCell>
                  <TableCell><Badge variant={i.status === "paid" ? "default" : "secondary"}>{statusLabel(i.status)}</Badge></TableCell>
                  <TableCell className="flex gap-1">
                    <Button size="icon" variant="ghost" onClick={() => setViewId(i.id)}><Eye className="h-4 w-4" /></Button>
                    {canEdit && <>
                      <Button size="icon" variant="ghost" onClick={() => openEdit(i)}><Pencil className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => remove(i.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                    </>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent></Card>

      {/* Editor */}
      <Dialog open={editorOpen} onOpenChange={(o) => { setEditorOpen(o); if (!o) resetEditor(); }}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingId ? "تعديل الفاتورة" : "إنشاء فاتورة"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>العميل</Label>
                <Select value={customerId} onValueChange={setCustomerId}>
                  <SelectTrigger><SelectValue placeholder="اختر عميلاً" /></SelectTrigger>
                  <SelectContent>{customers.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>الحالة</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">مسودة</SelectItem>
                    <SelectItem value="sent">مرسلة</SelectItem>
                    <SelectItem value="paid">مدفوعة</SelectItem>
                    <SelectItem value="cancelled">ملغاة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <Label>بنود الفاتورة</Label>
                <Button type="button" size="sm" variant="outline" onClick={addLine}><Plus className="h-4 w-4 ml-1" /> إضافة بند</Button>
              </div>
              <div className="border rounded-md overflow-x-auto">
                <Table>
                  <TableHeader><TableRow>
                    <TableHead className="min-w-[140px]">المنتج</TableHead>
                    <TableHead className="min-w-[160px]">الوصف</TableHead>
                    <TableHead className="w-24">الكمية</TableHead>
                    <TableHead className="w-28">سعر الوحدة</TableHead>
                    <TableHead className="w-28">الإجمالي</TableHead>
                    <TableHead className="w-12"></TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {lines.map((l, i) => (
                      <TableRow key={i}>
                        <TableCell>
                          <Select value={l.product_id ?? ""} onValueChange={(v) => onPickProduct(i, v)}>
                            <SelectTrigger className="h-8"><SelectValue placeholder="—" /></SelectTrigger>
                            <SelectContent>{products.map((p: any) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell><Input className="h-8" value={l.description} onChange={(e) => updateLine(i, { description: e.target.value })} /></TableCell>
                        <TableCell><Input className="h-8" type="number" min="0" step="1" value={l.quantity} onChange={(e) => updateLine(i, { quantity: Number(e.target.value) })} /></TableCell>
                        <TableCell><Input className="h-8" type="number" min="0" step="0.01" value={l.unit_price} onChange={(e) => updateLine(i, { unit_price: Number(e.target.value) })} /></TableCell>
                        <TableCell className="font-medium">{fmtMoney(l.quantity * l.unit_price)}</TableCell>
                        <TableCell><Button size="icon" variant="ghost" type="button" onClick={() => removeLine(i)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>ملاحظات</Label>
                <Input value={notes} onChange={(e) => setNotes(e.target.value)} />
              </div>
              <div className="space-y-1 text-sm bg-muted/50 rounded-md p-3">
                <div className="flex justify-between"><span className="text-muted-foreground">المجموع الفرعي</span><span>{fmtMoney(totals.subtotal)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">ضريبة ({(TAX_RATE * 100).toFixed(0)}%)</span><span>{fmtMoney(totals.tax)}</span></div>
                <div className="flex justify-between font-bold text-base border-t pt-1 mt-1"><span>الإجمالي</span><span>{fmtMoney(totals.total)}</span></div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditorOpen(false)}>إلغاء</Button>
            <Button onClick={save}>{editingId ? "تحديث" : "حفظ"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Viewer */}
      <InvoiceViewer id={viewId} onClose={() => setViewId(null)} />
    </>
  );
}

function InvoiceViewer({ id, onClose }: { id: string | null; onClose: () => void }) {
  const { data } = useQuery({
    queryKey: ["invoice-detail", id],
    enabled: !!id,
    queryFn: async () => {
      const [{ data: inv }, { data: items }] = await Promise.all([
        supabase.from("invoices").select("*, customers(name)").eq("id", id!).single(),
        supabase.from("invoice_items").select("*").eq("invoice_id", id!),
      ]);
      return { inv, items: items ?? [] };
    },
  });

  return (
    <Dialog open={!!id} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader><DialogTitle>تفاصيل الفاتورة {data?.inv?.invoice_number}</DialogTitle></DialogHeader>
        {data?.inv && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><span className="text-muted-foreground">العميل: </span>{data.inv.customers?.name ?? "—"}</div>
              <div><span className="text-muted-foreground">التاريخ: </span>{fmtDate(data.inv.issue_date)}</div>
            </div>
            <Table>
              <TableHeader><TableRow><TableHead>الوصف</TableHead><TableHead>الكمية</TableHead><TableHead>السعر</TableHead><TableHead>الإجمالي</TableHead></TableRow></TableHeader>
              <TableBody>
                {data.items.map((it: any) => (
                  <TableRow key={it.id}>
                    <TableCell>{it.description}</TableCell>
                    <TableCell>{it.quantity}</TableCell>
                    <TableCell>{fmtMoney(it.unit_price)}</TableCell>
                    <TableCell className="font-medium">{fmtMoney(it.total)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="space-y-1 text-sm bg-muted/50 rounded-md p-3">
              <div className="flex justify-between"><span className="text-muted-foreground">المجموع الفرعي</span><span>{fmtMoney(data.inv.subtotal)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">الضريبة</span><span>{fmtMoney(data.inv.tax)}</span></div>
              <div className="flex justify-between font-bold border-t pt-1"><span>الإجمالي</span><span>{fmtMoney(data.inv.total)}</span></div>
            </div>
            {data.inv.notes && <div className="text-sm"><span className="text-muted-foreground">ملاحظات: </span>{data.inv.notes}</div>}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
