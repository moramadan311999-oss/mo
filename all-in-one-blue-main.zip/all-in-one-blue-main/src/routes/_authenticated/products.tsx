import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Package, Trash2 } from "lucide-react";
import { EmptyState } from "@/components/EmptyState";
import { fmtMoney } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/products")({ component: Products });

function Products() {
  const qc = useQueryClient();
  const { user, hasAnyRole } = useAuth();
  const canEdit = !!user && hasAnyRole(["admin", "manager"]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", sku: "", price: "0", cost: "0", stock: "0" });

  const { data = [] } = useQuery({
    queryKey: ["products"],
    queryFn: async () => (await supabase.from("products").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from("products").insert({
      name: form.name, sku: form.sku || null,
      price: Number(form.price), cost: Number(form.cost), stock: Number(form.stock),
    });
    if (error) return toast.error(error.message);
    toast.success("تمت الإضافة");
    setOpen(false);
    setForm({ name: "", sku: "", price: "0", cost: "0", stock: "0" });
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  const remove = async (id: string) => {
    if (!confirm("حذف؟")) return;
    await supabase.from("products").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  return (
    <>
      <PageHeader title="المنتجات" description="إدارة المنتجات والمخزون" action={canEdit && (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 ml-1" /> منتج جديد</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>إضافة منتج</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <div><Label>اسم المنتج *</Label><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><Label>الكود (SKU)</Label><Input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} dir="ltr" /></div>
              <div className="grid grid-cols-3 gap-2">
                <div><Label>السعر</Label><Input type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></div>
                <div><Label>التكلفة</Label><Input type="number" step="0.01" value={form.cost} onChange={(e) => setForm({ ...form, cost: e.target.value })} /></div>
                <div><Label>المخزون</Label><Input type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} /></div>
              </div>
              <DialogFooter><Button type="submit">حفظ</Button></DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      )} />
      <Card><CardContent className="p-0">
        {data.length === 0 ? <EmptyState icon={Package} title="لا توجد منتجات" /> :
          <Table>
            <TableHeader><TableRow>
              <TableHead>الاسم</TableHead><TableHead>الكود</TableHead><TableHead>السعر</TableHead><TableHead>التكلفة</TableHead><TableHead>المخزون</TableHead>
              {canEdit && <TableHead></TableHead>}
            </TableRow></TableHeader>
            <TableBody>
              {data.map((p: any) => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.name}</TableCell>
                  <TableCell dir="ltr" className="text-start">{p.sku ?? "—"}</TableCell>
                  <TableCell>{fmtMoney(p.price)}</TableCell>
                  <TableCell>{fmtMoney(p.cost)}</TableCell>
                  <TableCell><Badge variant={p.stock > 10 ? "default" : p.stock > 0 ? "secondary" : "destructive"}>{p.stock}</Badge></TableCell>
                  {canEdit && <TableCell><Button size="icon" variant="ghost" onClick={() => remove(p.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>}
                </TableRow>
              ))}
            </TableBody>
          </Table>}
      </CardContent></Card>
    </>
  );
}
