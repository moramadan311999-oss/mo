
GRANT USAGE ON SCHEMA tests TO sandbox_exec;
GRANT EXECUTE ON FUNCTION tests.run_rls_tests() TO sandbox_exec;
GRANT EXECUTE ON FUNCTION tests._become(uuid)     TO sandbox_exec;
GRANT EXECUTE ON FUNCTION tests._as_postgres()    TO sandbox_exec;
GRANT EXECUTE ON FUNCTION tests._try_insert(text) TO sandbox_exec;
GRANT EXECUTE ON FUNCTION tests._try_update(text) TO sandbox_exec;
GRANT EXECUTE ON FUNCTION tests._try_delete(text) TO sandbox_exec;

-- Silence search_path linter on helpers.
ALTER FUNCTION tests._try_insert(text) SET search_path = public;
ALTER FUNCTION tests._try_update(text) SET search_path = public;
ALTER FUNCTION tests._try_delete(text) SET search_path = public;
ALTER FUNCTION tests._as_postgres()    SET search_path = public;
