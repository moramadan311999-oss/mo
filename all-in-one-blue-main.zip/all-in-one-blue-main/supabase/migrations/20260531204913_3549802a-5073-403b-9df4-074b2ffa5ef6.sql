
GRANT USAGE ON SCHEMA tests TO authenticated;
GRANT EXECUTE ON FUNCTION tests._try_insert(text), tests._try_update(text),
  tests._try_delete(text), tests._become(uuid) TO authenticated;
