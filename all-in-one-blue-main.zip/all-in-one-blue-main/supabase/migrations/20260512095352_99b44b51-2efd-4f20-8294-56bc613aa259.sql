ALTER TABLE public.customers DROP COLUMN IF EXISTS tax_number;
ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS shop_name text;
ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS phone2 text;
ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS notes text;