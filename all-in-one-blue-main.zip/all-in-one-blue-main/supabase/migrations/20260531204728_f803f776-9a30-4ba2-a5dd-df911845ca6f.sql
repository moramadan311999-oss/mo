
CREATE SCHEMA IF NOT EXISTS tests;
REVOKE ALL ON SCHEMA tests FROM PUBLIC;

-- Helpers -------------------------------------------------------
CREATE OR REPLACE FUNCTION tests._become(uid uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, auth AS $$
BEGIN
  PERFORM set_config('request.jwt.claims',
    json_build_object('sub', uid::text, 'role','authenticated')::text, true);
  PERFORM set_config('role', 'authenticated', true);
END $$;

CREATE OR REPLACE FUNCTION tests._as_postgres() RETURNS void
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  PERFORM set_config('role', 'postgres', true);
END $$;

CREATE OR REPLACE FUNCTION tests._try_insert(sql text) RETURNS boolean
LANGUAGE plpgsql AS $$
BEGIN
  EXECUTE sql; RETURN true;
EXCEPTION
  WHEN insufficient_privilege THEN RETURN false;
  WHEN OTHERS THEN
    IF SQLSTATE = '42501' THEN RETURN false; END IF;
    RAISE;
END $$;

CREATE OR REPLACE FUNCTION tests._try_update(sql text) RETURNS int
LANGUAGE plpgsql AS $$
DECLARE rc int;
BEGIN
  EXECUTE sql; GET DIAGNOSTICS rc = ROW_COUNT; RETURN rc;
EXCEPTION WHEN insufficient_privilege THEN RETURN -1;
  WHEN OTHERS THEN IF SQLSTATE='42501' THEN RETURN -1; END IF; RAISE;
END $$;

CREATE OR REPLACE FUNCTION tests._try_delete(sql text) RETURNS int
LANGUAGE plpgsql AS $$
DECLARE rc int;
BEGIN
  EXECUTE sql; GET DIAGNOSTICS rc = ROW_COUNT; RETURN rc;
EXCEPTION WHEN insufficient_privilege THEN RETURN -1;
  WHEN OTHERS THEN IF SQLSTATE='42501' THEN RETURN -1; END IF; RAISE;
END $$;

-- Main suite ----------------------------------------------------
CREATE OR REPLACE FUNCTION tests.run_rls_tests()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, tests
AS $fn$
DECLARE
  v_admin   uuid := '11111111-1111-1111-1111-111111111111';
  v_manager uuid := '22222222-2222-2222-2222-222222222222';
  v_acct    uuid := '33333333-3333-3333-3333-333333333333';
  v_hr      uuid := '44444444-4444-4444-4444-444444444444';
  v_emp     uuid := '55555555-5555-5555-5555-555555555555';
  v_emp_id  uuid;
  v_n       int;
  v_pass    int := 0;
BEGIN
  PERFORM tests._as_postgres();

  INSERT INTO auth.users (id, instance_id, aud, role, email,
    encrypted_password, email_confirmed_at, created_at, updated_at,
    raw_app_meta_data, raw_user_meta_data, is_sso_user, is_anonymous)
  SELECT u.id, '00000000-0000-0000-0000-000000000000', 'authenticated',
         'authenticated', u.id::text || '@rls.test',
         '', now(), now(), now(), '{}'::jsonb, '{}'::jsonb, false, false
  FROM (VALUES (v_admin),(v_manager),(v_acct),(v_hr),(v_emp)) u(id)
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.user_roles(user_id, role) VALUES
    (v_admin,'admin'), (v_manager,'manager'),
    (v_acct,'accountant'), (v_hr,'hr'), (v_emp,'employee')
  ON CONFLICT (user_id, role) DO NOTHING;

  INSERT INTO public.customers (name) VALUES ('__rls_test_cust__');
  INSERT INTO public.products  (name, price) VALUES ('__rls_test_prod__', 1);
  INSERT INTO public.suppliers (name) VALUES ('__rls_test_sup__');
  INSERT INTO public.invoices  (invoice_number) VALUES ('__RLS_INV__');
  INSERT INTO public.purchase_orders (po_number) VALUES ('__RLS_PO__');
  INSERT INTO public.employees (full_name) VALUES ('__rls_test_emp__')
    RETURNING id INTO v_emp_id;
  INSERT INTO public.payroll (employee_id, pay_period, net_salary)
    VALUES (v_emp_id, '__rls__', 1);

  -- customers ---------------------------------------------------
  PERFORM tests._become(v_emp);
  SELECT count(*) INTO v_n FROM public.customers WHERE name='__rls_test_cust__';
  IF v_n <> 0 THEN RAISE EXCEPTION 'FAIL employee saw customers'; END IF;
  IF tests._try_insert($q$INSERT INTO public.customers(name) VALUES ('x')$q$) THEN
    RAISE EXCEPTION 'FAIL employee inserted customers'; END IF;
  v_pass := v_pass + 2;

  PERFORM tests._become(v_hr);
  SELECT count(*) INTO v_n FROM public.customers WHERE name='__rls_test_cust__';
  IF v_n <> 0 THEN RAISE EXCEPTION 'FAIL hr saw customers'; END IF;
  v_pass := v_pass + 1;

  PERFORM tests._become(v_acct);
  SELECT count(*) INTO v_n FROM public.customers WHERE name='__rls_test_cust__';
  IF v_n <> 1 THEN RAISE EXCEPTION 'FAIL accountant blind to customers'; END IF;
  IF NOT tests._try_insert($q$INSERT INTO public.customers(name) VALUES ('a')$q$) THEN
    RAISE EXCEPTION 'FAIL accountant could not insert customer'; END IF;
  v_pass := v_pass + 2;

  PERFORM tests._become(v_manager);
  IF tests._try_update($q$UPDATE public.customers SET notes='m' WHERE name='__rls_test_cust__'$q$) < 1 THEN
    RAISE EXCEPTION 'FAIL manager could not update customer'; END IF;
  v_pass := v_pass + 1;

  PERFORM tests._become(v_admin);
  IF tests._try_delete($q$DELETE FROM public.customers WHERE name='__rls_test_cust__'$q$) < 1 THEN
    RAISE EXCEPTION 'FAIL admin could not delete customer'; END IF;
  v_pass := v_pass + 1;

  -- products ----------------------------------------------------
  PERFORM tests._become(v_emp);
  SELECT count(*) INTO v_n FROM public.products WHERE name='__rls_test_prod__';
  IF v_n <> 0 THEN RAISE EXCEPTION 'FAIL employee saw products'; END IF;

  PERFORM tests._become(v_acct);
  SELECT count(*) INTO v_n FROM public.products WHERE name='__rls_test_prod__';
  IF v_n <> 1 THEN RAISE EXCEPTION 'FAIL accountant blind to products'; END IF;
  IF tests._try_insert($q$INSERT INTO public.products(name,price) VALUES ('p',1)$q$) THEN
    RAISE EXCEPTION 'FAIL accountant inserted product'; END IF;

  PERFORM tests._become(v_manager);
  IF NOT tests._try_insert($q$INSERT INTO public.products(name,price) VALUES ('mp',1)$q$) THEN
    RAISE EXCEPTION 'FAIL manager could not insert product'; END IF;
  v_pass := v_pass + 4;

  -- suppliers ---------------------------------------------------
  PERFORM tests._become(v_acct);
  SELECT count(*) INTO v_n FROM public.suppliers WHERE name='__rls_test_sup__';
  IF v_n <> 0 THEN RAISE EXCEPTION 'FAIL accountant saw suppliers'; END IF;
  PERFORM tests._become(v_manager);
  SELECT count(*) INTO v_n FROM public.suppliers WHERE name='__rls_test_sup__';
  IF v_n <> 1 THEN RAISE EXCEPTION 'FAIL manager blind to suppliers'; END IF;
  IF NOT tests._try_insert($q$INSERT INTO public.suppliers(name) VALUES ('s')$q$) THEN
    RAISE EXCEPTION 'FAIL manager could not insert supplier'; END IF;
  v_pass := v_pass + 3;

  -- invoices ----------------------------------------------------
  PERFORM tests._become(v_emp);
  SELECT count(*) INTO v_n FROM public.invoices WHERE invoice_number='__RLS_INV__';
  IF v_n <> 0 THEN RAISE EXCEPTION 'FAIL employee saw invoices'; END IF;
  PERFORM tests._become(v_acct);
  IF NOT tests._try_insert($q$INSERT INTO public.invoices(invoice_number) VALUES ('i')$q$) THEN
    RAISE EXCEPTION 'FAIL accountant could not insert invoice'; END IF;
  PERFORM tests._become(v_hr);
  IF tests._try_insert($q$INSERT INTO public.invoices(invoice_number) VALUES ('hri')$q$) THEN
    RAISE EXCEPTION 'FAIL hr inserted invoice'; END IF;
  v_pass := v_pass + 3;

  -- purchase_orders --------------------------------------------
  PERFORM tests._become(v_acct);
  SELECT count(*) INTO v_n FROM public.purchase_orders WHERE po_number='__RLS_PO__';
  IF v_n <> 0 THEN RAISE EXCEPTION 'FAIL accountant saw POs'; END IF;
  IF tests._try_insert($q$INSERT INTO public.purchase_orders(po_number) VALUES ('p1')$q$) THEN
    RAISE EXCEPTION 'FAIL accountant inserted PO'; END IF;
  PERFORM tests._become(v_manager);
  IF NOT tests._try_insert($q$INSERT INTO public.purchase_orders(po_number) VALUES ('p2')$q$) THEN
    RAISE EXCEPTION 'FAIL manager could not insert PO'; END IF;
  v_pass := v_pass + 3;

  -- employees --------------------------------------------------
  PERFORM tests._become(v_acct);
  SELECT count(*) INTO v_n FROM public.employees WHERE full_name='__rls_test_emp__';
  IF v_n <> 0 THEN RAISE EXCEPTION 'FAIL accountant saw employees'; END IF;
  IF tests._try_insert($q$INSERT INTO public.employees(full_name) VALUES ('e')$q$) THEN
    RAISE EXCEPTION 'FAIL accountant inserted employee'; END IF;
  PERFORM tests._become(v_hr);
  IF NOT tests._try_insert($q$INSERT INTO public.employees(full_name) VALUES ('hre')$q$) THEN
    RAISE EXCEPTION 'FAIL hr could not insert employee'; END IF;
  v_pass := v_pass + 3;

  -- payroll ----------------------------------------------------
  PERFORM tests._become(v_manager);
  SELECT count(*) INTO v_n FROM public.payroll;
  IF v_n <> 0 THEN RAISE EXCEPTION 'FAIL manager saw payroll'; END IF;
  PERFORM tests._become(v_emp);
  IF tests._try_insert(
       format($q$INSERT INTO public.payroll(employee_id,pay_period,net_salary) VALUES (%L,'x',999)$q$, v_emp_id)) THEN
    RAISE EXCEPTION 'FAIL employee inserted payroll'; END IF;
  PERFORM tests._become(v_hr);
  IF NOT tests._try_insert(
       format($q$INSERT INTO public.payroll(employee_id,pay_period,net_salary) VALUES (%L,'h',1)$q$, v_emp_id)) THEN
    RAISE EXCEPTION 'FAIL hr could not insert payroll'; END IF;
  PERFORM tests._become(v_acct);
  SELECT count(*) INTO v_n FROM public.payroll;
  IF v_n < 1 THEN RAISE EXCEPTION 'FAIL accountant blind to payroll'; END IF;
  v_pass := v_pass + 4;

  -- user_roles -------------------------------------------------
  PERFORM tests._become(v_emp);
  IF tests._try_insert(
       $q$INSERT INTO public.user_roles(user_id,role) VALUES ('55555555-5555-5555-5555-555555555555','admin')$q$) THEN
    RAISE EXCEPTION 'FAIL employee self-granted admin'; END IF;
  v_pass := v_pass + 1;

  -- Sentinel: raise to roll back all seed/fixture rows.
  RAISE EXCEPTION 'OK:%', v_pass;
END
$fn$;

-- Lock the suite away from app roles.
REVOKE ALL ON FUNCTION tests.run_rls_tests()    FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION tests._become(uuid)      FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION tests._as_postgres()     FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION tests._try_insert(text)  FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION tests._try_update(text)  FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION tests._try_delete(text)  FROM PUBLIC, anon, authenticated;
